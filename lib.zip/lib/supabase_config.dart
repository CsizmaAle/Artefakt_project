import 'package:supabase_flutter/supabase_flutter.dart';

// Configure these via --dart-define at build/run time
// flutter run --dart-define=SUPABASE_URL=... --dart-define=SUPABASE_ANON_KEY=...
const String kSupabaseUrl = String.fromEnvironment(
  'SUPABASE_URL',
  defaultValue: 'https://aujjvvccubepguzafcxz.supabase.co',
);
const String kSupabaseAnonKey = String.fromEnvironment('SUPABASE_ANON_KEY');

bool _supabaseInited = false;
Future<void> initSupabase() async {
  if (_supabaseInited) return;
  await Supabase.initialize(
    url: kSupabaseUrl,
    anonKey: kSupabaseAnonKey.isEmpty ? 'REPLACE_WITH_YOUR_SUPABASE_ANON_KEY' : kSupabaseAnonKey,
  );
  _supabaseInited = true;
}

SupabaseClient get supabase => Supabase.instance.client;
