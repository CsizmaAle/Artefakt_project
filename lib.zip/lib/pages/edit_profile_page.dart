import 'dart:io';

import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import 'package:artefakt_v1/services/profile_service.dart';
import 'package:artefakt_v1/supabase_config.dart';

class EditProfilePage extends StatefulWidget {
  const EditProfilePage({super.key});

  @override
  State<EditProfilePage> createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {
  final _formKey = GlobalKey<FormState>();
  final _usernameCtrl = TextEditingController();
  final _bioCtrl = TextEditingController();
  String? _photoUrl;
  bool _saving = false;
  bool _uploading = false;
  double _uploadProgress = 0.0;

  @override
  void dispose() {
    _usernameCtrl.dispose();
    _bioCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickAndUploadPhoto(String uid) async {
    try {
      final picker = ImagePicker();
      final picked = await picker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 1200,
        imageQuality: 85,
      );
      if (picked == null) return;

      final file = File(picked.path);
      final path = 'user_uploads/$uid/profile_${DateTime.now().millisecondsSinceEpoch}.jpg';

      setState(() {
        _uploading = true;
        _uploadProgress = 0.0;
      });

      final fileBytes = await file.readAsBytes();
      final storage = supabase.storage.from('user_uploads');

      // Upload with progress is not directly exposed; show indeterminate bar
      setState(() => _uploadProgress = 0);
      await storage.uploadBinary(
        path,
        fileBytes,
        fileOptions: const FileOptions(contentType: 'image/jpeg', upsert: false),
      );
      final url = storage.getPublicUrl(path);
      if (!mounted) return;
      setState(() => _photoUrl = url);
      // Persist immediately so the profile photo is saved even without pressing Save
      try {
        await ProfileService().updateProfile(uid: uid, photoUrl: url);
      } catch (_) {}
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Photo uploaded')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Upload failed: $e')),
      );
    } finally {
      if (mounted) {
        setState(() {
          _uploading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = Supabase.instance.client.auth.currentUser;
    if (user == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Edit Profile')),
        body: const Center(child: Text('You need to be signed in.')),
      );
    }
    final uid = user.id;
    final profileFuture = supabase.from('profiles').select().eq('id', uid).maybeSingle();

    return Scaffold(
      appBar: AppBar(title: const Text('Edit Profile')),
      body: FutureBuilder<Map<String, dynamic>?>(
        future: profileFuture,
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting && !snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final data = snap.data ?? <String, dynamic>{};
          final currentUsername = (data['username'] as String?) ?? '';
          final currentBio = (data['bio'] as String?) ?? '';
          final currentPhoto = (data['photo_url'] as String?) ?? '';

          if (_photoUrl == null) _photoUrl = currentPhoto;
          if (_usernameCtrl.text.isEmpty) _usernameCtrl.text = currentUsername;
          if (_bioCtrl.text.isEmpty) _bioCtrl.text = currentBio;

          return SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      CircleAvatar(
                        radius: 44,
                        backgroundColor: Colors.grey.shade300,
                        backgroundImage: (_photoUrl != null && _photoUrl!.isNotEmpty)
                            ? NetworkImage(_photoUrl!)
                            : null,
                        child: (_photoUrl == null || _photoUrl!.isEmpty)
                            ? const Icon(Icons.person, size: 44)
                            : null,
                      ),
                      const SizedBox(width: 16),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          FilledButton.icon(
                            onPressed: _saving || _uploading ? null : () => _pickAndUploadPhoto(uid),
                            icon: const Icon(Icons.photo),
                            label: const Text('Change photo'),
                          ),
                          if (_uploading) ...[
                            const SizedBox(height: 8),
                            SizedBox(
                              width: 180,
                              child: LinearProgressIndicator(value: _uploadProgress == 0 ? null : _uploadProgress),
                            ),
                          ],
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),
                  TextFormField(
                    controller: _usernameCtrl,
                    decoration: const InputDecoration(
                      labelText: 'Username',
                      prefixText: '@',
                    ),
                    textInputAction: TextInputAction.next,
                    validator: (v) {
                      final u = (v ?? '').trim().toLowerCase();
                      if (u.isEmpty) return 'Username is required';
                      if (!RegExp(r'^[a-z0-9_.]{3,20}$').hasMatch(u)) {
                        return '3-20 chars: letters, digits, . or _';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: _bioCtrl,
                    decoration: const InputDecoration(
                      labelText: 'Bio',
                      hintText: 'Tell people about yourself',
                    ),
                    minLines: 2,
                    maxLines: 5,
                  ),
                  const SizedBox(height: 24),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      onPressed: _saving
                          ? null
                          : () async {
                              if (!_formKey.currentState!.validate()) return;
                              setState(() => _saving = true);
                              final svc = ProfileService();
                              final desired = _usernameCtrl.text.trim().toLowerCase();
                              final bio = _bioCtrl.text.trim();
                              try {
                                final newUsername = desired == currentUsername ? null : desired;
                                await svc.updateProfile(
                                  uid: uid,
                                  newUsername: newUsername,
                                  bio: bio,
                                  photoUrl: _photoUrl,
                                );
                                if (mounted) {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(content: Text('Profile updated')),
                                  );
                                  Navigator.of(context).pop();
                                }
                              } catch (e) {
                                if (mounted) {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(content: Text('Update failed: $e')),
                                  );
                                }
                              } finally {
                                if (mounted) setState(() => _saving = false);
                              }
                            },
                      child: _saving
                          ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                          : const Text('Save changes'),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
