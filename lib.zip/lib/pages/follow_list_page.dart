import 'package:artefakt_v1/supabase_config.dart';
import 'package:flutter/material.dart';
import 'package:artefakt_v1/pages/profile_public_page.dart';

class FollowListPage extends StatelessWidget {
  final String userId;
  final bool isFollowers; // true => list of people who follow userId; false => who userId follows
  const FollowListPage({super.key, required this.userId, required this.isFollowers});

  @override
  Widget build(BuildContext context) {
    final field = isFollowers ? 'target_id' : 'follower_id';
    final otherField = isFollowers ? 'follower_id' : 'target_id';
    final title = isFollowers ? 'Followers' : 'Following';

    final stream = supabase
        .from('follows')
        .stream(primaryKey: ['pair_id'])
        .eq(field, userId);

    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: StreamBuilder<List<Map<String, dynamic>>>(
        stream: stream,
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(child: Text('Failed to load $title'));
          }
          if (snapshot.connectionState == ConnectionState.waiting && !snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final docs = snapshot.data ?? const [];
          if (docs.isEmpty) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24.0),
                child: Text(isFollowers ? 'No followers yet' : 'Not following anyone yet'),
              ),
            );
          }
          return ListView.separated(
            itemCount: docs.length,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (context, index) {
              final data = docs[index];
              final otherUid = (data[otherField] as String?) ?? '';
              if (otherUid.isEmpty) {
                return const ListTile(title: Text('Unknown user'));
              }
              final userStream = supabase
                  .from('profiles')
                  .stream(primaryKey: ['id'])
                  .eq('id', otherUid)
                  .limit(1);
              return StreamBuilder<List<Map<String, dynamic>>>(
                stream: userStream,
                builder: (context, userSnap) {
                  final udata = (userSnap.data?.isNotEmpty ?? false) ? userSnap.data!.first : <String, dynamic>{};
                  final username = (udata['username'] as String?) ?? otherUid;
                  final displayName = (udata['display_name'] as String?) ?? '';
                  final photoUrl = (udata['photo_url'] as String?) ?? '';
                  return ListTile(
                    leading: CircleAvatar(
                      backgroundImage: photoUrl.isNotEmpty ? NetworkImage(photoUrl) : null,
                      child: photoUrl.isEmpty ? const Icon(Icons.person) : null,
                    ),
                    title: Text(displayName.isNotEmpty ? displayName : '@$username'),
                    subtitle: displayName.isNotEmpty ? Text('@$username') : null,
                    onTap: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (_) => ProfilePublicPage(userId: otherUid),
                        ),
                      );
                    },
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}
