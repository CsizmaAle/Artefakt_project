import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'profile_page.dart';
import 'search_page.dart';
// Dacă NU folosești rute numite pentru login, poți importa direct AuthPage și
// folosi pushAndRemoveUntil în _onLogoutPressed (vezi comentariul din funcție).
// import 'auth_page.dart';

class HomePage extends StatefulWidget {
  final String email;
  const HomePage({super.key, required this.email});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _index = 0;

  // Paginile între care navigăm (placeholder — le poți înlocui cu pagini reale)
  List<Widget> get _pages => const [
        Center(child: Text("Home")),
        Center(child: Text("Messages")),
        Center(child: Text("New post")),
        Center(child: Text("Profilul tău")),
      ];

  Future<void> _onLogoutPressed() async {
    final confirmed = await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('Delogare'),
            content: const Text('Ești sigură că vrei să te deloghezi?'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('Nu'),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('Da'),
              ),
            ],
          ),
        ) ??
        false;

    if (!confirmed) return;

    // VARIANTA 1 – cu rută numită (ai nevoie de '/login' în MaterialApp.routes)
    await Supabase.instance.client.auth.signOut();
    Navigator.of(context).pushNamedAndRemoveUntil('/login', (_) => false);

    // VARIANTA 2 – fără rute numite (de-comentează dacă preferi asta)
    // Navigator.of(context).pushAndRemoveUntil(
    //   MaterialPageRoute(builder: (_) => const AuthPage()),
    //   (route) => false,
    // );
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      const Center(child: Text('Home')),
      const SearchPage(),
      const Center(child: Text('Messages')),
      const Center(child: Text('New post')),
      const ProfilePage(),
    ];
    final safeIndex = _index.clamp(0, pages.length - 1);
    const titles = ['Home', 'Search', 'Messages', 'New Post', 'Profile'];
    final currentTitle = titles[safeIndex];

    return Scaffold(
      appBar: AppBar(
        title: Text(currentTitle),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: _onLogoutPressed,
          ),
        ],
      ),
      body: pages[safeIndex],
      bottomNavigationBar: NavigationBar(
        selectedIndex: safeIndex,
        onDestinationSelected: (int newIndex) {
          setState(() {
            _index = newIndex;
          });
        },
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.search), label: 'Search'),
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), label: 'Messages'),
          NavigationDestination(icon: Icon(Icons.post_add_rounded), label: 'New Post'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'Profile'),
        ],
      ),
    );
  }
}
