import 'package:artefakt_v1/supabase_config.dart';

class FollowService {

  String _pairId(String followerId, String targetId) => '${followerId}_${targetId}';

  Future<void> follow({required String currentUid, required String targetUid}) async {
    if (currentUid == targetUid) {
      throw Exception('You cannot follow yourself.');
    }

    final pairId = _pairId(currentUid, targetUid);
    final target = await supabase.from('users').select('id').eq('id', targetUid).maybeSingle();
    if (target == null) throw Exception('Target user does not exist.');

    // Insert; rely on unique constraint to avoid duplicates
    await supabase.from('follows').insert({
      'pair_id': pairId,
      'follower_id': currentUid,
      'target_id': targetUid,
      'created_at': DateTime.now().toIso8601String(),
    },);
  }

  Future<void> unfollow({required String currentUid, required String targetUid}) async {
    if (currentUid == targetUid) {
      throw Exception('You cannot unfollow yourself.');
    }

    final pairId = _pairId(currentUid, targetUid);
    await supabase.from('follows').delete().eq('pair_id', pairId);
  }
}
